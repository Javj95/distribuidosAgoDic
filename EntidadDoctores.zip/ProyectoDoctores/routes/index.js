const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

const Doctor = require('../models/doctor');

// Ruta dedicada a  regresar la lista de expedientes completa
router.get("/:cedula", (req, res) => {
    const cedula = req.params.cedula;

    Doctor.findOne({ cedula: cedula })
        .exec()
        .then(doc => {
            const response = {
                cedula: doc.cedula,
                nombre: doc.nombre,
                apellidoPaterno: doc.apellidoPaterno,
                apellidoMaterno: doc.apellidoMaterno,
                departamento: doc.departamento,
                puesto: doc.puesto,
                especialidad: doc.especialidad,
                permisoExpedientes: doc.permisoExpedientes,
                request: {
                    type: "GET",
                    url: "http://localhost:3000/" + doc.cedula
                }

            };
            res.status(200).json(response);
        }).catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            })
        });

});

// Ruta dedicada a registrar expedientes nuevos
router.post("/", (req, res) => {
    console.log(req.body);
    const doctor = new Doctor({
        cedula: req.body.curp,
        nombre: req.body.nombre,
        apellidoPaterno: req.body.apellidoPaterno,
        apellidoMaterno: req.body.apellidoMaterno,
        departamento: req.body.departamento,
        puesto: req.body.puesto,
        especialidad: req.body.especialidad,
        permisoExpedientes: req.body.permisoExpedientes,
        permisoExpedientes: []
    });
    expediente.save()
        .then(result => {
            console.log(result);
        }).catch(err => console.log(err));
    res.status(200).json({
        message: "Funciona!",
        doctor: doctor
    });
});

// Ruta dedicada a registrar expedientes nuevos
router.post("/entry/:cedula", (req, res) => {
    const cedula = req.params.cedula;
    const entry = req.body.entry;
    Expediente.findOneAndUpdate({ cedula: cedula }, 
        {historial: [{ body: entry}]}, {new: true})
        .exec()
        .then(doc => {
            const response = {
                cedula: doc.cedula,
                nombre: doc.nombre,
                apellidoPaterno: doc.apellidoPaterno,
                apellidoMaterno: doc.apellidoMaterno,
                departamento: doc.departamento,
                puesto: doc.puesto,
                especialidad: doc.especialidad,
                permisoExpedientes: doc.permisoExpedientes,
                request: {
                    type: "GET",
                    url: "http://localhost:3000/" + doc.cedula
                }

            };
            res.status(200).json(response);
        }).catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            })
        });
});
module.exports = router;