const mongoose=require('mongoose');
const esquema=mongoose.Schema;

const estEsquema=new esquema({
    id:String,
    nombre:String,
    apellidoPaterno:String,
    apellidoMaterno:String,
    fechaNacimiento:String,
    edad:Number,
    sexo:String,
    fechaRegistro:String,
    domicilio:String,
    historial:Array
});

module.exports=mongoose.model('expedientes',estEsquema);
                            //nombre de la collecion
                                //en la BD