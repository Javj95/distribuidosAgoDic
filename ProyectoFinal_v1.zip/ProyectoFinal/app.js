const express=require('express');
const app=express();
const mongoose=require('mongoose');
app.use(express.urlencoded({extended:true} ))//permite mandar datos a traves de un FORMULARIO


//conectarse a la BD
mongoose.connect('mongodb://localhost/base1').then(
    db=>console.log('Conectado a la bd')
).catch(err=>console.log("Error al conectarse:"+ err) );

//importar rutas
const indexRutas= require('./routes/index');


//configurar vistas
app.set('view engine','ejs');
app.set('views',__dirname + '/vistas');

app.use('/', indexRutas);


app.listen(3000, ()=>{
    console.log("Express desde puerto 3000");
});