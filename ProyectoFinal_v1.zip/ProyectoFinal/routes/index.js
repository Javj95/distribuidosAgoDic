const { Router } = require('express');
const  express=require('express');
const router=express.Router();
router.get("/",(req,res)=>{
    res.send("Hola");

})

module.exports=router;

//En esta parte pondremos todas las rutas